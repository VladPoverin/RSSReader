/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.util.Scanner;
import obrazce.Ctverec;
import obrazce.Kruh;
import obrazce.Obdelnik;
import zlomky.Zlomek;

/**
 *
 * @author povervl1
 */
public class Main {

    public static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
       
        Ctverec [] ctverec = new Ctverec [3];
        for(int i = 0; i < 3; i++){
            ctverec [i] = new Ctverec(input.nextDouble());           
    }
        for(int i = 0; i < ctverec.length; i++ ){
            System.out.println(ctverec[i]  );
        }
        /* Zlomek zlomek;
        
        double citatel;
        double jmenovatel;
        
        System.out.println("Zadejte citatele");
        citatel = input.nextDouble();
        System.out.println("Zadejte jmenovatele");
        jmenovatel = input.nextDouble();
        
        zlomek = new Zlomek(citatel, jmenovatel);
        
        System.out.println("Hodnota zlomku je: " + zlomek.vratHodnotu());
        
        System.out.println( "Jmenovatel je:" + zlomek.getJmenovatel());
        /*System.out.println( "Hodnota je:" + zlomek.());*/
 /*zlomek.zktrat(10);
        System.out.println("Jmenovatel je: " + zlomek.getJmenovatel());
         */
    }

}
